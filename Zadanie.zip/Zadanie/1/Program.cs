using System;
 
namespace App
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Podaj pierwsza liczbe");
                string number1Str = Console.ReadLine();
               
                Console.WriteLine("Podaj druga liczbe");
                string number2Str = Console.ReadLine();
 
                int number1, number2;
                if(int.TryParse(number1Str, out number1) &&
                    int.TryParse(number2Str, out number2))
                {
                    bool divisible = false;
                    if (number1 >= number2)
                        divisible = number1 % number2 == 0;
                    else
                        divisible = number2 % number1 == 0;
 
                    if(divisible)
                        Console.WriteLine("Liczba wieksza jest podzielna przez mniejsza");
                    else
                        Console.WriteLine("Liczba wieksza nie jest podzielna przez mniejsza");
                }
                else
                    Console.WriteLine("Niepoprawne liczby");
            }
        }
    }
}